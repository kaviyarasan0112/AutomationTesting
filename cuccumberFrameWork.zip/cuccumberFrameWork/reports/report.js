$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/main/java/com/feature/ReleaseResidue.feature");
formatter.feature({
  "name": "sSupport Release Residue File From International",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "To select the sSupport Release Residue File From International",
  "description": "",
  "keyword": "Scenario"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Click on the link maintenance",
  "keyword": "Given "
});
formatter.match({
  "location": "CreateBankAccountAdministration.clickOnTheLinkMaintenance()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Mouse Hover on the operations and click on Stored Procedure Runner",
  "keyword": "And "
});
formatter.match({
  "location": "ReleaseResidueFromFileInternational.mouseHoverOnTheOperationsAndClickOnStoredProcedureRunner()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "select Dividends from the dropdown category",
  "keyword": "And "
});
formatter.match({
  "location": "ReleaseResidueFromFileInternational.selectDividendFromTheDropdownCategory(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "select sSupportReleaseResiduesFromFileInternational from the stored procedure dropdown",
  "keyword": "And "
});
formatter.match({
  "location": "ReleaseResidueFromFileInternational.selectSSupportReleaseResiduesFromFileInternationalFromTheStoredProcedureDropdown(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Input parameters should be displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "CreateResidueFileFromInternational.inputParametersShouldBeDisplayed()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Enter the input parameters",
  "description": "",
  "keyword": "Scenario"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Click on the link maintenance",
  "keyword": "Given "
});
formatter.match({
  "location": "CreateBankAccountAdministration.clickOnTheLinkMaintenance()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Mouse Hover on the operations and click on Stored Procedure Runner",
  "keyword": "And "
});
formatter.match({
  "location": "ReleaseResidueFromFileInternational.mouseHoverOnTheOperationsAndClickOnStoredProcedureRunner()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "select Dividends from the dropdown category",
  "keyword": "And "
});
formatter.match({
  "location": "ReleaseResidueFromFileInternational.selectDividendFromTheDropdownCategory(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "select sSupportReleaseResiduesFromFileInternational from the stored procedure dropdown",
  "keyword": "And "
});
formatter.match({
  "location": "ReleaseResidueFromFileInternational.selectSSupportReleaseResiduesFromFileInternationalFromTheStoredProcedureDropdown(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Input parameters should be displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "CreateResidueFileFromInternational.inputParametersShouldBeDisplayed()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter the clientURN as 1",
  "keyword": "When "
});
formatter.match({
  "location": "ReleaseResidueFromFileInternational.enterTheClientURNAs(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter the payment date as 31-Mar-2021",
  "keyword": "And "
});
formatter.match({
  "location": "ReleaseResidueFromFileInternational.enterThePaymentDate(String)"
});
formatter.result({
  "status": "passed"
});
});