package com.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;


import com.stepDefinitions.SelBase;

public class SCorrespondencePage extends SelBase {
	
	public SCorrespondencePage(RemoteWebDriver driver) {
		SelBase.driver=driver;	
	}
	
	
	
	public SHandOffPage correspondenceSubmit6() {
		WebElement submit = driver.findElementById("Systembuttongroup_btnSubmit");
		submit.click();
		return new SHandOffPage(driver);
	}



}
