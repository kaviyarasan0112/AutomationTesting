package com.pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.stepDefinitions.SelBase;

public class RegisterDividendOptionPage extends SelBase{
	
	public RegisterDividendOptionPage Maintenance() throws InterruptedException, IOException {
		
		  WebElement maintenance = driver.findElementByXPath("//img[@alt='Maintenance']") ;
		  click(maintenance); 
		  return this;
	}
	
	public RegisterDividendOptionPage bankAccountAdministration() {
		
		  WebElement bankAccountAdministration = driver.findElementByXPath("//span[contains(text(),'Bank account admini...')]/parent::a");
		  mouseHover(bankAccountAdministration); 
		  return this;
	}

	public RegisterDividendOptionPage createBankAccountAdministration() {
		
		  WebElement createBankAccount = driver.findElementByXPath("//table[@id='Create Bank Account']//tr//a"); 
		  click(createBankAccount);
		  windowHandle();
		  WebElement workItem = driver.findElementByXPath("//span[contains(text(),'Work Item')]/parent::a");
		  Actions builder=new Actions(driver);
		  builder.moveToElement(workItem).perform();
		  WebElement createWIT = driver.findElementByLinkText("Create WIT");
		  createWIT.click();
		  return this; 
	}
	


}
