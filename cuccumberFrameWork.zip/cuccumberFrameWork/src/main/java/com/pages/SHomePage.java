package com.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.stepDefinitions.SelBase;

/**
 * @author thiyagk
 *
 */
public class SHomePage extends SelBase {

	public SHomePage(RemoteWebDriver driver) {
		SelBase.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public SHomePage Maintenance() throws InterruptedException, IOException {

		WebElement maintenance = driver.findElementByXPath("//img[@alt='Maintenance']");
		click(maintenance);
		return this;
	}

	public SHomePage ClientAdministration() throws IOException {
		WebElement clientAdministration = driver.findElementByXPath("//span[contains(@title,'Client administration')]");
		mouseHover(clientAdministration);
		return this;
	}

	@FindBy(how = How.XPATH, using = "//table[@id='Offering - SR Div Prx S212']//tr//a/span")
	public WebElement OfferingSRDivPrxS793;

	public SHomePage OfferingSRDivPrxS793() throws InterruptedException {
		Thread.sleep(3000);
		mouseHover(OfferingSRDivPrxS793);
		return this;
	}

	/*
	 * @FindBy(how=How.XPATH,using=
	 * "//table[@id='AmendOfferingSRDivPrxS212']//tr//a") public WebElement
	 * amendOffering; public SAmendDividendOfferingPage amendDivOffering() {
	 * //click(amendOffering); //windowHandle(); return new
	 * SAmendDividendOfferingPage(driver,node, test); }
	 */

	public SHomePage taskDividend() throws InterruptedException, IOException {
		WebElement taskDividend = driver.findElementByXPath("//table[@id='Task -Dividend']");
		mouseHover(taskDividend);
		return this;
	}
	/*
	 * public SCreateDividendTaskPage createDivTask() throws InterruptedException,
	 * IOException {
	 * 
	 * WebElement createDividendTask = locateElement("xpath",
	 * "(//a[contains(text(),'Create')])[20]"); click(createDividendTask);
	 * windowHandle();
	 * 
	 * return new SCreateDividendTaskPage(driver,node,test); }
	 */

	public SHomePage bankAccountAdministration() {

		WebElement bankAccountAdministration = driver
				.findElementByXPath("//span[contains(text(),'Bank account admini...')]/parent::a");
		mouseHover(bankAccountAdministration);

		return this;
	}

	public SCreateBankAccountPage createBankAccountAdministration() {

		WebElement createBankAccount = driver.findElementByXPath("//table[@id='Create Bank Account']//tr//a");
		click(createBankAccount);
		windowHandle();

		return new SCreateBankAccountPage(driver);
	}

	// To click on Reporting Stored Procedure

	public SHomePage operations() {

		WebElement operations = driver.findElement(By.partialLinkText("Operations"));
		Actions builder = new Actions(driver);
		builder.moveToElement(operations).perform();
		driver.findElement(By.xpath("//span[contains(text(),'Reporting Stored Pr...')]/..")).click();
		return this;

	}
	// To click on Reporting Stored Procedure
	public SHomePage clickOnStoredProcedureRunner() {
		WebElement operations = driver.findElement(By.partialLinkText("Operations"));
		Actions builder = new Actions(driver);
		builder.moveToElement(operations).perform();
		driver.findElement(By.xpath("//table[@id='Stored Procedure Runner']//tr//a")).click();
		return this;
	}
	

}
