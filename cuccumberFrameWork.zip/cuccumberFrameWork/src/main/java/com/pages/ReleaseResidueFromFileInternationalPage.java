package com.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import com.stepDefinitions.SelBase;

public class ReleaseResidueFromFileInternationalPage extends SelBase {

	public ReleaseResidueFromFileInternationalPage(RemoteWebDriver driver) {
		SelBase.driver = driver;
	}
	
	public ReleaseResidueFromFileInternationalPage clientURN(String clientID) {
		WebElement clientURN = driver.findElementById("sfrmParameters_ctl00_@ClientURN_rrptxb_@ClientURN");
		/*
		 * String actualText = driver.findElementByXPath(
		 * "//table[@class='control']/tbody/tr/th/label/span[contains(text(),'ClientURN')]"
		 * ).getText(); Assert.assertEquals(actualText, expectedText);
		 */
		clientURN.sendKeys(clientID);
		return this;
	}
	
	public ReleaseResidueFromFileInternationalPage paymentDate(String paymentDate) {

		WebElement paymentDateEle = driver.findElementByXPath(
				"//table[@class='control']/tbody/tr/th/label/span[contains(text(),'PaymentDate')]/ancestor::th/following-sibling::td/input");
		paymentDateEle.sendKeys(paymentDate);
		return this;
	}

}
