package com.pages;

import org.openqa.selenium.remote.RemoteWebDriver;


import com.stepDefinitions.SelBase;


public class SHandOffPage extends SelBase {

	public SHandOffPage(RemoteWebDriver driver) {
		SelBase.driver=driver;
	}
	

}
