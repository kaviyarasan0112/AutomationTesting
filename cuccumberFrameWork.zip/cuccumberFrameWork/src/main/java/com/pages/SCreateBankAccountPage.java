package com.pages;



import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import com.stepDefinitions.SelBase;

public class SCreateBankAccountPage extends SelBase{
	
	public SCreateBankAccountPage(RemoteWebDriver driver) {
		SelBase.driver=driver;		
	}

	public SCreateBankAccountPage client(String clientID) {
		WebElement client = driver.findElementByCssSelector("#sfrmCreateBankAccount_ctl00_csClient_rrpClientSearchTxt_csClient");
		clearAndType(client, clientID);
		return this;
	}
	
	public SCreateBankAccountPage go() throws InterruptedException {
		WebElement go = driver.findElementByXPath("//u[contains(text(),'G')]/parent::a") ;
		go.click();
		Thread.sleep(3000);
		WebElement dd = driver.findElementByCssSelector("#sfrmCreateBankAccount_ctl00_csClient_rrpClientSearchLst_csClient");
		dropdown(dd, "1 - Royal Dutch Shell plc");
		return this;
	}
	
	public SCreateBankAccountPage bankAccountName(String BankAccName) {
		WebElement bankAccountName = driver.findElementByCssSelector("#sfrmCreateBankAccount_ctl00_txtBankAccountName_rrptxb_txtBankAccountName");
		//String actual = bankAccountName.getText();
		clearAndType(bankAccountName, BankAccName);
		//Assert.assertEquals(actual, "Bank account name");
		return this;
	}
	
	public SCreateBankAccountPage bankAccountType(String BankAccountType) {
		WebElement bankAccountType = driver.findElementByCssSelector("#sfrmCreateBankAccount_ctl00_ddlstBankAccountType__rrp_list_ddlstBankAccountType");
		dropdown(bankAccountType,BankAccountType );
		return this;
	}
	
	public SCreateBankAccountPage bankAccountUse() {
		WebElement bankAccountUse = driver.findElementByCssSelector("#sfrmCreateBankAccount_ctl00_ddlstBankAccountUse__rrp_list_ddlstBankAccountUse");
		Select bankAccUseDD=new Select(bankAccountUse);
		//List<WebElement> options = bankAccUseDD.getOptions();
		//String text = options.get(2).getText();
		bankAccUseDD.selectByVisibleText("Continuous");
		//Assert.assertEquals(text, "Continuous");
		return this;
	}
	
	public SCreateBankAccountPage bankAcountNumber(String BankAccNumber) {
		WebElement bankAccountNumber = driver.findElementByCssSelector("#sfrmCreateBankAccount_ctl00_txtBankAccountNumber_rrptxb_txtBankAccountNumber");
		append(bankAccountNumber, BankAccNumber);
		//String bankaccNuText = locateElement("xpath", "//span[contains(text(),'Bank account number')]").getText();
		//Assert.assertEquals(bankaccNuText, " Bank account number *");
		return this;
		}
	
	public SCreateBankAccountPage splitValueBankAcc() throws InterruptedException {
		WebElement splitValueBankAccont = driver.findElementByCssSelector("#sfrmCreateBankAccount_ctl00_ddlstSplitValueBankAccount>table>tbody>tr>td>select");
		Thread.sleep(3000);
		dropdown(splitValueBankAccont,"No");
		return this;
	}
	
	public SCreateBankAccountPage sortCode(String SC1,String SC2,String SC3) {
		
		  WebElement sortCode1 =driver.findElementByXPath("//span[@id='sfrmCreateBankAccount_ctl00_scSortCode_rrpsrtcdescSortCode']/input[1]");
		  append(sortCode1, SC1); 
		  WebElement sortCode2 = driver.findElementByXPath("//span[@id='sfrmCreateBankAccount_ctl00_scSortCode_rrpsrtcdescSortCode']/input[2]");
		  append(sortCode2, SC2); 
		  WebElement sortCode3 = driver.findElementByXPath("//span[@id='sfrmCreateBankAccount_ctl00_scSortCode_rrpsrtcdescSortCode']/input[3]"); 
		  append(sortCode3, SC3);
		 
		return this;
	}
	
	public SCreateBankAccountPage sortCodeGo() {
		
		  WebElement sortCodeGo = driver.findElementById("sfrmCreateBankAccount_ctl00_btnGo");
		  click(sortCodeGo);
		 
		return this;
	}
	
	public SCreateBankAccountPage noOfReservedCheques() {
		
		  WebElement noOfReservedCheques = driver.findElementById("sfrmCreateBankAccount_ctl00_txtNumOfReservedCheques_rrptxb_txtNumOfReservedCheques");  
		  append(noOfReservedCheques, "6");
		 
		return this;
	}
	
	public SCreateBankAccountPage thresholdValue() {
		
		  WebElement thresholdValue = driver.findElementById("sfrmCreateBankAccount_ctl00_txtE13BThreshold_rrptxb_txtE13BThreshold");
		  append(thresholdValue, "3");
		 
		return this;
	}
	
	public SlinkToChequeSignatureTextPage submitBanKAcc() {
		
		  WebElement submitBankAcc = driver.findElementById("btngrpSubmit_btnSubmit");
		  click(submitBankAcc);
		 
		return new SlinkToChequeSignatureTextPage(driver);
	}
}
