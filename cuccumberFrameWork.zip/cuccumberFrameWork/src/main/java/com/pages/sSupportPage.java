package com.pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.stepDefinitions.SelBase;

public class sSupportPage extends SelBase {

	public sSupportPage(RemoteWebDriver driver) {
		SelBase.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public sSupportPage category(String category) {

		WebElement categoryEle = driver.findElement(By.id(
				"sfrmSelectStoredProcedure_ctl00_ddlstStoredProcedureCategory__rrp_list_ddlstStoredProcedureCategory"));
		Select divReps = new Select(categoryEle);
		divReps.selectByVisibleText(category);
		/*
		 * List<WebElement> options2 = divReps.getOptions(); for (WebElement eachOptions
		 * : options2) { if (eachOptions.getText().equalsIgnoreCase(category)) {
		 * eachOptions.click(); break; } }
		 */
		return this;
	}

	public sSupportPage selectStoredProcedure(String spName) {
		
		WebElement storedProcedure = driver.findElementById("sfrmSelectStoredProcedure_ctl00_ddlstStoredProcedureNames__rrp_list_ddlstStoredProcedureNames");
		Select divReps = new Select(storedProcedure);
		divReps.selectByVisibleText(spName);
		//List<WebElement> sp = driver.findElements(By.xpath("//select[@id='sfrmSelectStoredProcedure_ctl00_ddlstStoredProcedureNames__rrp_list_ddlstStoredProcedureNames']/option"));
		/*
		 * for (WebElement eachSP : sp) { if (eachSP.getText().equalsIgnoreCase(spName))
		 * { eachSP.click(); break; } }
		 */		
		return this;
	}

}
