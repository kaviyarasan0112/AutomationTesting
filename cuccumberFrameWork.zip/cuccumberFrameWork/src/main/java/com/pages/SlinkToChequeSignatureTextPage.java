package com.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.stepDefinitions.SelBase;

public class SlinkToChequeSignatureTextPage extends SelBase {
	
	public SlinkToChequeSignatureTextPage(RemoteWebDriver driver) {
		SelBase.driver=driver;
		
	}
	
	public SCorrespondencePage chequeSignatoryText() throws InterruptedException {
		
		  WebElement noneRadioButton = driver.findElementById("sfrmCreateBankAccount_ctl00_tblChequeSignatoryText_RadioColumnSelector_0");
		
		  verifyDisplayed(noneRadioButton);
		  click(noneRadioButton);
		  Thread.sleep(3000);
		  WebElement submit = driver.findElementByXPath("(//td[@class='buttonsystem']/a)[2]");
		  click(submit);
		  WebElement next = driver.findElementById("btngrpNavigation_btnNext");
		 click(next);
		 WebElement targetCompletionDateEle = driver.findElementById("sfrmActivity_ctl00_txtTargetDate_rrptxb_txtTargetDate");
			append(targetCompletionDateEle, "24-Jan-2021");
			WebElement submit1 = driver.findElementById("Systembuttongroup_btnSubmit");
			submit1.click();
			WebElement submit2= driver.findElementById("Systembuttongroup_btnSubmit");
			submit2.click();
			WebElement submit3 = driver.findElementById("Systembuttongroup_btnSubmit");
			submit3.click();
			WebElement submit4 = driver.findElementById("Systembuttongroup_btnSubmit");
			submit4.click();
			WebElement submit5 = driver.findElementById("Systembuttongroup_btnSubmit");
			submit5.click();
			WebElement submit6 = driver.findElementById("Systembuttongroup_btnSubmit");
			submit6.click();
			
		 
		 
		  return new SCorrespondencePage(driver);
	}
	
	
}
