package com.stepDefinitions;

import java.io.IOException;

import com.pages.SHomePage;
import com.pages.sSupportPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class CreateResidueFileFromInternational extends SelBase {
	SHomePage homePage;
	sSupportPage sSupportPage;

	@Given("Mouse Hover on the operations and click on Reporting Stored Procedure")
	public void mouseHoverOnTheOperationsAndClickOnReportingStoredProcedure() throws InterruptedException, IOException {
		homePage=new SHomePage(driver);
		homePage.Maintenance();
		homePage.operations();
	}

	@And("select the (.*) from category dropdown")
	public void selectTheDividendReportsFromCategoryDropdown(String category) {
		sSupportPage = new sSupportPage(driver);
		sSupportPage.category(category);

	}

	@And("select the sSupport (.*)")
	public void selectTheSSupportSSupportCreateResidueFileInternational(String sp) {
		sSupportPage.selectStoredProcedure(sp);
	}

	@Then("Input parameters should be displayed")
	public void inputParametersShouldBeDisplayed() {

	}

}
