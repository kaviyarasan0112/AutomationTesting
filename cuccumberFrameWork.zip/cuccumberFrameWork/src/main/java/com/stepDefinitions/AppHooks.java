package com.stepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.Scenario;
import cucumber.api.java.Before;

public class AppHooks extends SelBase {
	
	@Before
	public void precondition(Scenario sc) throws InterruptedException{
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		Thread.sleep(3000);
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://siriusukfta1.uk1test.group.internal/fta1/RRP.UI.Web/Default.aspx?_height=680&_width=1280");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println(sc.getName());
	
	}
	/*
	 * @After public void postcondition(Scenario sc){
	 * System.out.println(sc.getStatus()); driver.close();
	 * 
	 * }
	 */
}
		

