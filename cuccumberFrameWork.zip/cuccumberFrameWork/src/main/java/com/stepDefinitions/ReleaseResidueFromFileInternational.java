package com.stepDefinitions;

import java.util.List;

import com.pages.ReleaseResidueFromFileInternationalPage;
import com.pages.SHomePage;
import com.pages.sSupportPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;



public class ReleaseResidueFromFileInternational extends SelBase{
	
	SHomePage homePage;
	sSupportPage sSupportPage;
	ReleaseResidueFromFileInternationalPage residuePage;
	
	@Given("Mouse Hover on the operations and click on Stored Procedure Runner")
	public void mouseHoverOnTheOperationsAndClickOnStoredProcedureRunner() {
		homePage=new SHomePage(driver);
		homePage.clickOnStoredProcedureRunner();
	}
	
	@And("select (.*) from the dropdown category")
	public void selectDividendFromTheDropdownCategory(String Dividend) {
		sSupportPage = new sSupportPage(driver);
		sSupportPage.category(Dividend);
	}

	@And("select (.*) from the stored procedure dropdown")
	public void selectSSupportReleaseResiduesFromFileInternationalFromTheStoredProcedureDropdown(String spName) {
		sSupportPage.selectStoredProcedure(spName);
	}
	
	@When("Enter the clientURN as (.*)")
	public void enterTheClientURNAs(String clientURN) {
		residuePage=new ReleaseResidueFromFileInternationalPage(driver);
	    residuePage.clientURN(clientURN);
	}

	
	@And("Enter the payment date as (.*)")
	public void enterThePaymentDate(String paymentDate) {
		
		residuePage.paymentDate(paymentDate);
	}
	


}
