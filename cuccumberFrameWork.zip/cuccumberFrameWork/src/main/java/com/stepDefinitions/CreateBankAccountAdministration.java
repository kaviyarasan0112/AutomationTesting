package com.stepDefinitions;

import java.io.IOException;

import com.pages.SCorrespondencePage;
import com.pages.SCreateBankAccountPage;
import com.pages.SHomePage;
import com.pages.SlinkToChequeSignatureTextPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreateBankAccountAdministration extends SelBase{
	
	SHomePage homePage;
	SCreateBankAccountPage createBankAccountPage;
	SlinkToChequeSignatureTextPage chequeSignatoryTextPage; 
	SCorrespondencePage CorrespondencePage;
	
	@Given("Click on the link maintenance")
	public void clickOnTheLinkMaintenance() throws InterruptedException, IOException {
		homePage=new SHomePage(driver);
		homePage.Maintenance();
		
	}

	@Given(":  MouseHover on the Bank account Adminstration")
	public void mousehoverOnTheBankAccountAdminstration() {
	    homePage.bankAccountAdministration();
	}

	@Given(": click on the create Bank Account link")
	public void clickOnTheCreateBankAccountLink() {
	    homePage.createBankAccountAdministration();
	}

	@When(": Enter the clientID (.*)")
	public void enterTheClientID(String clientID) {
	   createBankAccountPage=new SCreateBankAccountPage(driver);
	   createBankAccountPage.client(clientID);
	}

	@When(": click on the link Go")
	public void clickOnTheLinkGo() throws InterruptedException {
		createBankAccountPage.go();
	}

	@When(": Enter the BankAccountName (.*)")
	public void enterTheBankAccountNameTestBankAccount(String BankAccName ) {
		createBankAccountPage.bankAccountName(BankAccName);
	}

	@When(": Enter the BankAccountType (.*)")
	public void enterTheBankAccountTypeCashPayment(String BankAccountType) {
		createBankAccountPage.bankAccountType(BankAccountType);
	}

	@When(": Enter the BankAccountUse")
	public void enterTheBankAccountUse() {
		createBankAccountPage.bankAccountUse();
	}

	@When(": Enter the BankAccountNumber (.*)")
	public void enterTheBankAccountNumber(String BankAccountNumber) {
		createBankAccountPage.bankAcountNumber(BankAccountNumber);
	}

	@When(": Select the split value Bank Account as No")
	public void selectTheSplitValueBankAccountAsNo() throws InterruptedException {
		createBankAccountPage.splitValueBankAcc();
	}

	@When(": Enter the sortCode (.*)(.*)(.*)")
	public void enterTheSortCode(String SC1,String SC2,String SC3) {
		createBankAccountPage.sortCode(SC1, SC2, SC3);
	}

	@When(": Click on the Go in sortcode")
	public void clickOnTheGoInSortcode() {
		createBankAccountPage.sortCodeGo();
	}

	@When(": Enter the reserved cheques and threshold value")
	public void enterTheReservedChequesAndThresholdValue() {
	    createBankAccountPage.noOfReservedCheques();
	    createBankAccountPage.thresholdValue();
	}

	@When(": Click on the submit button")
	public void clickOnTheSubmitButton() {
	    createBankAccountPage.submitBanKAcc();
	}

	@When(": Click on the radio button ChequeSignature")
	public void clickOnTheRadioButtonChequeSignature() throws InterruptedException {
		SlinkToChequeSignatureTextPage chequeSignatoryTextPage=new SlinkToChequeSignatureTextPage(driver);
		chequeSignatoryTextPage.chequeSignatoryText();
		
	}

	@Then(": Create Bank account should be created successfully")
	public void createBankAccountShouldBeCreatedSuccessfully() {
		 CorrespondencePage.correspondenceSubmit6();
	}

}
