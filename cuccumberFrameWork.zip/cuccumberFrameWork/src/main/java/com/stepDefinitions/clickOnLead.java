package com.stepDefinitions;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class clickOnLead extends SelBase {

	
	@When ("click on the crmsfa link")
	public void clickOnTheCrmsfaLink() {
		
	}
	
	@Then ("MyHome page should displayed")
	public void myHomePageShouldDisplayed() {
		

	}
	
	@When ("click on leads link")
	public void clickOnLeadsLink() {
		

	}
}
