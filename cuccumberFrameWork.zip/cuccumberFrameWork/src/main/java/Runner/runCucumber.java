package Runner;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.testng.AbstractTestNGCucumberTests;


@CucumberOptions(features= {"src/main/java/com/feature/ReleaseResidue.feature"},
				 glue= {"com/stepDefinitions"},  //Include the package name of the step definitions class
				 monochrome=true,//To remove the unwanted characters in the console
				 //tags= {"@functional","@regression"},
				 plugin= {"pretty","html:reports"},
				 snippets=SnippetType.CAMELCASE,
				 dryRun = false)//To get the step defintion in lower camel case
//src\main\java\com\feature
public class runCucumber extends AbstractTestNGCucumberTests {

}
