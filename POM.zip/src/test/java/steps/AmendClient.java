package steps;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.When;

public class AmendClient extends BaseClass {
	
	@When("Click on the link maintenance")
	public void clickOnTheLinkMaintenance() {
		
		 driver.findElementByXPath("//img[@alt='Maintenance']").click();
	}
	
	@When("MouseHover on the clientAdministration and client")
	public void mousehoverOnTheClientAdministrationAndClient() {
	    WebElement clientAdminstration = driver.findElementByXPath("//span[contains(@title,'Client administration')]");
	    Actions builder=new Actions(driver);
	    builder.moveToElement(clientAdminstration).perform();
	    WebElement client = driver.findElementByXPath("(//a[contains(text(),'Client')])[3]");
	    builder.moveToElement(client).perform();
	}
	    
	@When("Click on the link amend")
		public void ClickOnTheLinkAmend()  {
	    WebElement amend = driver.findElementByXPath("(//a[contains(text(),'Amend')])[2]");
	    amend.click(); 
	    Set<String> siriusWindow = driver.getWindowHandles();
	    List<String> listHandle=new ArrayList<String>(siriusWindow);
		String SecondWindow = listHandle.get(1);
		WebDriver minimizeSecWin = driver.switchTo().window(SecondWindow);
		minimizeSecWin.manage().window().minimize();
	}

	
	

}
