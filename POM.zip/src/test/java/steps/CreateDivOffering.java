package steps;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class CreateDivOffering extends BaseClass {
	
	@When("Click on the link create")
	public void clickOnCreate() throws InterruptedException {
		driver.findElementByXPath("(//a[contains(text(),'Create')])[3]").click();
		
		Set<String> siriusWindow = driver.getWindowHandles();
	    List<String> listHandle=new ArrayList<String>(siriusWindow);
		String SecondWindow = listHandle.get(1);
		WebDriver minimizeSecWin = driver.switchTo().window(SecondWindow);
		minimizeSecWin.manage().window().minimize();
		String firstWindow = listHandle.get(0);
		driver.switchTo().window(firstWindow);
		Thread.sleep(3000);

	}
	@When("Select the value offering from search for dropdown")
	public void selectOfferingFromSearchForDropdown() {
		WebElement searchFor = driver.findElementByXPath("//table[@class='control']/tbody/tr//select");
	  //("//table[@class='control']/tbody/tr//select");
		Select dd1=new Select(searchFor);
		dd1.selectByVisibleText("Client");
	
	}
	
	@When ("Enter the value in client textbox as (.*)")
	public void enterTheValueInClientTextbox(String clientID) {
		driver.findElementByXPath("//input[@type='text']").sendKeys(clientID);

	}
	@When ("Enter the value in offering textbox as (.*)")
	public void enterTheValueInOfferingTextbox(String offeringID) {
		driver.findElementByXPath("(//input[@type='text'])[2]").sendKeys(offeringID);

	}
	
	@When ("Click on the search button") 
	public void clickOnTheSearchButton() {
		driver.findElementById("midscreeen_btnSearch").click();

	}
	
	@When("Enable the checkbox") 
	public void enableTheCheckbox() {
		driver.findElementByXPath("//input[@type='checkbox']").click();

	}
	
	@When ("Click on the next button")
	public void clickOnTheNextButton() {
		driver.findElementByXPath("(//td[@class='buttonsystem']/a)[2]").click();
	}
	
	@When ("select the dividend from the product dropdown in maintain offering screen") 
	public void selectDividendFromProductDropDown() {
		WebElement product = driver.findElementByXPath("//select[@class='list']");
		Select dividend=new Select(product);
		dividend.selectByVisibleText("Dividend");
		driver.findElementByXPath("//a[@id='btngrp_btnNext']").click();
	}
	
	@When ("Click on the link Next in maintain offering screen")
	public void clickOnTheNextInMaintainOffering() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElementByXPath("//a[@id='btngrp_btnNext']").click();
	}
	@When ("select the status Active from the status dropdown in Dividend Offering details tab")
	public void selectActiveFromStatusDropdown() {
		WebElement status = driver.findElementByXPath("//select[@class='list']");
		Select statusDD=new Select(status);
		statusDD.selectByVisibleText("Active");
		Alert alert = driver.switchTo().alert();
		alert.accept();
	}
	
	@Given ("Enter the offeringFullName as (.*)")
	public void enterOfferingFullName(String offeringName) {
		WebElement offeringFullName = driver.findElementById("tabgrpOfferingClientDetails_tabMaintainDividendOffering1_sfrmDividendOfferingDetails1_ctl00_txtOfferingfullname_rrptxb_txtOfferingfullname");
		offeringFullName.sendKeys(offeringName);
	}
	
	@And ("Enter the offering short name as (.*)")
	public void enterTheOfferingShortNameAs(String offeringShortName) {
		WebElement offShortName = driver.findElementById("tabgrpOfferingClientDetails_tabMaintainDividendOffering1_sfrmDividendOfferingDetails1_ctl00_txtOfferingshortname_rrptxb_txtOfferingshortname");
		offShortName.sendKeys(offeringShortName);	
		driver.findElementByLinkText("Dividend Associate Offering");
	}
	
	
}	
	


