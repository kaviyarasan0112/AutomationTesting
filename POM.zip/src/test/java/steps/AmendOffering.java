package steps;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.When;

public class AmendOffering extends BaseClass {
	
	@When("MouseHover on the clientAdministration and Offering")
	public void mousehoverOnTheClientAdministrationAndClient() {
	    WebElement clientAdminstration = driver.findElementByXPath("//span[contains(@title,'Client administration')]");
	    Actions builder=new Actions(driver);
	    builder.moveToElement(clientAdminstration).perform();
	    WebElement offering = driver.findElementByXPath("//span[contains(@title,'Offering - SR Div Prx S793')]");
	    builder.moveToElement(offering).perform();
	}
	    
	@When("Click on the link amendoffering")
		public void ClickOnTheLinkAmend()  {
	    WebElement amend = driver.findElementByXPath("(//a[contains(text(),'Amend')])[3]");
	    amend.click(); 
	    Set<String> siriusWindow = driver.getWindowHandles();
	    List<String> listHandle=new ArrayList<String>(siriusWindow);
		String SecondWindow = listHandle.get(1);
		WebDriver minimizeSecWin = driver.switchTo().window(SecondWindow);
		minimizeSecWin.manage().window().minimize();
	}


}
