package SiriusApp.com;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class EnquiryParty {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "./ChromeDriver/chromedriver.exe");
		String property = System.getProperty("webdriver.chrome.driver");	
		System.out.println(property);
		//To disable notifications of the browser
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notofications");
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver(options);
		//to maximize the browser 
		driver.manage().window().maximize();
		driver.get("https://siriusukfta2.uk1test.group.internal/FTA2/RRP.UI.Web/Default.aspx?_height=680&_width=1280");
		
		Actions builder=new Actions(driver);
		WebElement Enquiry = driver.findElementByXPath("//img[@alt='Enquiries']");
		builder.moveToElement(Enquiry).perform();
		driver.findElementByXPath("//a[contains(text(),'Party')]").click();		
		driver.findElementByXPath("//input[@value='Parties']").click();
		driver.findElementByXPath("(//input[@type='text'])[1]").sendKeys("00679203906");
		driver.findElementByXPath("//td[@class='buttonsystem']").click();
		
		Thread.sleep(5000);
		//driver.close();
	}

}
