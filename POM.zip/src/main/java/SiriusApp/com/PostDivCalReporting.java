package SiriusApp.com;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PostDivCalReporting extends ReportingCommonMethods {
		
		@BeforeTest
		public void setFile() {
		fileNameOfExcel = "PostDivCalTD";
		}
		
		@Test(dataProvider = "TestData")
		public  void PostDivCalRep(String ClientName, String offeringTaskID) throws InterruptedException {
		driver.findElementByXPath("//table[@id='Dividends']//tr/td/a").click();
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> listHandle=new ArrayList<String>(windowHandles);
		String ReportingWindow = listHandle.get(1);
		driver.switchTo().window(ReportingWindow);
		Thread.sleep(3000);
		driver.findElementByXPath("(//a[@class='tile'])[8]").click();
		//To select a client
		Thread.sleep(5000);
		driver.switchTo().frame(0);
		WebElement client = driver.findElementByXPath("//div[contains(@id,'ReportViewerControl')]/select");
		Select dd1=new Select(client);
		dd1.selectByVisibleText(ClientName);
		//To select a client
		Thread.sleep(5000);
		WebElement offeringTask = driver.findElementByXPath("//div[@data-parametername='OfferingTaskID']/select");
		Select dd2=new Select(offeringTask);
		dd2.selectByVisibleText(offeringTaskID);
		//To click on the view Report
		driver.findElementByXPath("//td[@class='SubmitButtonCell']/input").click();
		
	}

}
