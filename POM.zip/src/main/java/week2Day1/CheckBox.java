package week2Day1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckBox {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "./ChromeDriver/chromedriver.exe");
		
		String property = System.getProperty("webdriver.chrome.driver");
		
		System.out.println(property);
					
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver();
						

		//to maximize the browser 
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  
		//to load application url
		driver.get("http://leafground.com/");
		
		driver.findElementByXPath("//h5[contains(text(),'Checkbox')]").click();
		
		driver.findElementByXPath("(//input[contains(@type,'checkbox')])[1]").click();
		
		driver.findElementByXPath("(//input[contains(@type,'checkbox')])[2]").click();
		
		WebElement SelChecked = driver.findElementByXPath("//label[text()='Confirm Selenium is checked']/following::input");
		System.out.println("TO confirm selenium is checked "+SelChecked.isSelected());
		
		WebElement deselectCheckbox = driver.findElementByXPath("(//label[text()='DeSelect only checked']/following::input)[2]");
		deselectCheckbox.click();
		
		Thread.sleep(3000);
		
		driver.findElementByXPath("(//label[text()='Select all below checkboxes ']/following::input)[1]").click();
		driver.findElementByXPath("(//label[text()='Select all below checkboxes ']/following::input)[2]").click();
		driver.findElementByXPath("(//label[text()='Select all below checkboxes ']/following::input)[3]").click();
		driver.findElementByXPath("(//label[text()='Select all below checkboxes ']/following::input)[4]").click();
		
		WebElement checkbox5 = driver.findElementByXPath("(//label[text()='Select all below checkboxes ']/following::input)[5]");
		checkbox5.click();
		System.out.println("CheckBox5 is currently selected "+checkbox5.isSelected());
		
		Thread.sleep(3000);
		
		driver.quit();
		
		
	}

}
