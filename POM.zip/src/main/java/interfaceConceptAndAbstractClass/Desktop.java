package interfaceConceptAndAbstractClass;

public  class Desktop implements Hardware,Software {
	
	int a,b,c;

	public int hardwareResources() {
		return c=a+b;
		
	}

	public void hardwareComponents() {
		System.out.println("Implemented Hardware Components");
		
	}
	
	public void softwareResources() {
		
		System.out.println("Implemented software Components");
		
	}
	
	public static void main(String[] args) {
		
		Desktop obj=new Desktop();
		obj.hardwareComponents();
		obj.hardwareResources();
		obj.softwareResources();
		
		System.out.println(Desktop.softwareApps);
		System.out.println(Desktop.hardwareName);
		
		
		
		
	}

	

}
