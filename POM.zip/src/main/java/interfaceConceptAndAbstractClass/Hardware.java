package interfaceConceptAndAbstractClass;

public interface Hardware {
	
	String hardwareName="Display";
	int hardwareResources();
	void hardwareComponents();
	
	

}
