package collections.week3.Day2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortUsingCollection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] input= {"HCL","Wipro","Aspire Systems","CTS","InfoSYS"};
		
		List<String> values=new ArrayList<String>();
		
		for (String eachInput : input) {
			values.add(eachInput);	
		}
		
		System.out.println(values);
		
		Collections.sort(values);
		
		for (int i = 0; i < values.size(); i++) {
			
			System.out.println(values.get(i));
			
		}

	}

}
