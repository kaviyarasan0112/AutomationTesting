package collections.week3.Day2;

import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicates {
	
	public static void main(String[] args) {
		
		String[] input= {"HCL","Wipro","Aspire Systems","CTS","InfoSYS","CTS","HCL"};
		
		Set<String> dup=new LinkedHashSet<String>();
		
		for (String eachValue : input) {
			dup.add(eachValue);
		}
		
		System.out.println(dup);
		
		
		
	}
	
	

}
