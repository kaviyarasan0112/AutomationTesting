package week3.Day1;

public class Mycar {

	public static void main(String[] args) {
		
		BMW obj=new BMW();
		obj.soundHorn();
		String brand = obj.brand;
		obj.switchOnAC();
		obj.airBags();
		
		
		  Car obj1=new Car();
		  obj1.applyBrake(); 
		  obj1.soundHorn(); 
		  obj1.switchOnAC();
		 
		
		Vehicle obj2=new Vehicle();
		obj2.applyBrake();
		obj2.soundHorn();
		String brand2 = obj2.brand;

	}

}
