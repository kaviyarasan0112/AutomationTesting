package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods {
	
	public ViewLeadPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public ViewLeadPage LeadCreated() {
		System.out.println("Lead Created successfully");
		return this;
	}

	public ViewLeadPage LeadCreatedEdited() {
		System.out.println("Lead Edited successfully");
		return this;
	}
	
	public ViewLeadPage verifyFirstName() {
		System.out.println("verified successfully");
		return this;
	}

	/*
	 * public EditLeadPage clickOnEditButton() {
	 * driver.findElementByLinkText("Edit").click(); return new
	 * EditLeadPage(driver);
	 * 
	 * }
	 * 
	 * public ViewLeadPage clickOnDeleteButton() {
	 * driver.findElementByLinkText("Delete").click(); return this;
	 * 
	 * }
	 * 
	 * public ViewLeadPage clickOnDuplicateLeadButton() {
	 * driver.findElementByLinkText("Duplicate Lead").click(); return this;
	 * 
	 * }
	 */

}
