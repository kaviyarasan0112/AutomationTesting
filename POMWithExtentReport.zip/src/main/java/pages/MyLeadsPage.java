package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethods;

public class MyLeadsPage extends ProjectSpecificMethods{
	
	public MyLeadsPage(ChromeDriver driver, ExtentTest test, ExtentTest node) {
		this.driver = driver;
		this.test = test;
		this.node = node;
	}
	
	
	public CreateLeadPage clickCreateLeadLink() {
		driver.findElementByLinkText("Create Lead").click();
		return new CreateLeadPage(driver, node, test);

	}
	
	public CreateLeadPage clickFindLeadLink() {
		driver.findElementByLinkText("Find Leads").click();
		return new CreateLeadPage(driver, test, node);

	}
	
	/*
	 * public MyLeadsPage(ChromeDriver driver) { this.driver=driver;
	 * 
	 * }
	 * 
	 * public MyLeadsPage clickOnCreateLead() {
	 * driver.findElementByLinkText("Create Lead").click(); return this; }
	 * 
	 * public MyLeadsPage enterCompanyName(String companyName) {
	 * driver.findElementById("createLeadForm_companyName").sendKeys(companyName);
	 * return this; }
	 * 
	 * public MyLeadsPage enterFirstName(String firstName) {
	 * driver.findElementById("createLeadForm_firstName").sendKeys(firstName);
	 * return this; }
	 * 
	 * public MyLeadPage enterLastName(String lastName) {
	 * driver.findElementById("createLeadForm_lastName").sendKeys(lastName); return
	 * this;
	 * 
	 * }
	 * 
	 * public ViewLeadPage clickOnCreateLeadButton() {
	 * driver.findElementByName("submitButton").click(); return new
	 * ViewLeadPage(driver); }
	 * 
	 * public FindLeadPage clickOnFindLeadsLink() {
	 * driver.findElementByLinkText("Find Leads").click(); return new
	 * FindLeadPage(driver);
	 * 
	 * }
	 */

}
