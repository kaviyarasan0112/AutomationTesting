package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	
	public LoginPage(ChromeDriver driver,ExtentTest node) {
		this.driver = driver;
		this.node = node;
		
	}

	// action+elementname
	public LoginPage enterUsername(String username) throws IOException {
		try {

			driver.findElementById("username").sendKeys(username);
			reportStep("username " + username + " entered successfully", "pass");

		} catch (Exception e) {
			reportStep("username " + username + " not entered successfully", "fail");
		}
		return this;

	}

	public LoginPage enterPassword(String password) throws IOException {

		try {

			driver.findElementById("password").sendKeys(password);
			reportStep("password " + password + " entered successfully", "pass");

		} catch (Exception e) {
			reportStep("password " + password + " not entered successfully", "fail");
		}

		return this;
	}

	public HomePage clickLogin() throws IOException {
		try {
			driver.findElementByClassName("decorativeSubmit").click();
			reportStep("login button is clicked", "pass");
		} catch (Exception e) {
			reportStep("login button is not clicked", "fail");
		}
		
		return new HomePage(driver,node);

	}
	
	/*
	 * public LoginPage(ChromeDriver driver, ExtentTest node) { this.driver=driver;
	 * this.node=node;
	 * 
	 * }
	 * 
	 * public LoginPage enterUserName(String username) { try {
	 * driver.findElementById("username").sendKeys(username);
	 * reportStep("Username"+username+"entered"+"successfully","Pass"); }
	 * catch(Exception e) {
	 * reportStep("Username"+username+"entered"+"successfully","Fail"); } return
	 * this;
	 * 
	 * }
	 * 
	 * public LoginPage enterPassword(String password) { try {
	 * driver.findElementById("password").sendKeys(password);
	 * reportStep("Username"+password+"entered"+"successfully","Pass"); }
	 * catch(Exception e) {
	 * reportStep("Username"+password+"not entered"+"successfully","Fail"); }
	 * 
	 * return this; }
	 * 
	 * public LogoutPage clickLogin() {
	 * driver.findElementByClassName("decorativeSubmit").click(); return new
	 * LogoutPage(driver); }
	 */
}
