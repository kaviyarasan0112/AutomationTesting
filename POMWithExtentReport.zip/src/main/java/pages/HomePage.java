package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	
	public HomePage(ChromeDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}
	
	
	public LoginPage clickLogout() {
		driver.findElementByClassName("decorativeSubmit").click();
		
		return new LoginPage(driver,node);
	}
	
	public MyHomePage clickCrmsfaLink() {
		driver.findElementByLinkText("CRM/SFA").click();
		return new MyHomePage(driver,test,node);
	}
	
	
	
	
}
