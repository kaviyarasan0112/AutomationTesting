package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class FindLeadPage extends ProjectSpecificMethods {
	
	public FindLeadPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public FindLeadPage clickOnLinkPhone() {
		driver.findElementByXPath("//span[text()='Phone']").click();
		return this;
	}
	public FindLeadPage enterPhoneNo(String phoneNumber) {
		driver.findElementByXPath("//input[@name='phoneNumber']").sendKeys(phoneNumber);
		return this;
	}
	public FindLeadPage clickOnFindLeadsButton() throws InterruptedException {
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(2000);
		return this;
	}
	public ViewLeadPage clickOnFirstLeadID() {
		driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").click();
		return new ViewLeadPage(driver);

	}
	
	
	

}
