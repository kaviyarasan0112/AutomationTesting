package testCases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;
import pages.LogoutPage;
import pages.MyHomePage;

public class CreateLead extends ProjectSpecificMethods {
	
	@BeforeTest
	
		public void provideDetails() {
			testName="createLead";
			testDescription="To check the CreateLead functionality";
			testAuthor="Kavi";
			testCategory="Smoke";
			
		
		excelFileName="CreateLeadTD";
	}
	
	@Test(dataProvider="Data")
	public void createLead(String username,String password,String companyName,String firstName,String lastName ) throws InterruptedException, IOException {
		//MyHomePage hp=new MyHomePage();
		new LoginPage(driver,node)
		.enterUsername(username)
		.enterPassword(password)
		.clickLogin()
		.clickCrmsfaLink()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyName(companyName)
		.enterFirstName(firstName)
		.enterLastName(lastName)
		.clickCreateLead();

	}

	
		
}
