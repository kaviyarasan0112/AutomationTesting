package testCases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginAndLogout extends ProjectSpecificMethods {
	
	@BeforeTest
	public void provideDetails() {
		testName = "LoginAndLogout";
		testDescription = "login and logout with positive credential";
		testAuthor = "Hari";
		testCategory = "Smoke";
		excelFileName = "LoginData";
	}
	
	@Test(dataProvider = "Data")
	public void loginAndLogout(String username, String password) throws InterruptedException, IOException {
	//	LoginPage lp = new LoginPage();
		
		new LoginPage(driver,node)
		.enterUsername(username)
		.enterPassword(password)
		.clickLogin();
		//.clickLogout();
		
	}

}
