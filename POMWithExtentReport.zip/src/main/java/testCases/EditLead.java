package testCases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class EditLead extends ProjectSpecificMethods{
	
	@BeforeTest
	public void provideDetails() {
		testName="EditLead";
		testDescription="To check the EditLead functionality";
		testAuthor="Kavi";
		testCategory="Smoke";
		excelFileName="EditLeadTestData";
	}
	
	@Test(dataProvider="Data")
	public void runEditLead(String username,String password,String phoneNumber,String companyName) throws InterruptedException {
		new LoginPage(driver,node)
		.enterUsername(username)
		.enterPassword(password)
		.clickLogin()
		.clickCrmsfaLink()
		.clickLeadsLink()
		.clickFindLeadLink()
		.clickOnLinkPhone()
		.enterPhoneNo(phoneNumber)
		.clickOnFindLeadsButton()
		.clickOnFirstLeadID()
		.clickOnEditButton()
		.editTheCompanyName(companyName)
		.clickOnUpdate()
		.LeadCreatedEdited();
		

	}

}
