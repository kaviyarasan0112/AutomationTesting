import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReporting {
	
	public static void main(String[] args) throws IOException {
		
		//Create the physical HTML report
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./ExtentReports/result.html");
		//Create the actula report date
		ExtentReports extent=new ExtentReports();
		
		//Attach the physical report to the actula report
		extent.attachReporter(reporter);
		
		//Create the testcase with details
		ExtentTest testCase1 = extent.createTest("Login Test", "To check the functionality of login");
		testCase1.assignAuthor("Kavi");
		testCase1.assignCategory("Smoke");
		
		//Test step status
		testCase1.pass("Enter the username as demosalesmanager is success",MediaEntityBuilder.createScreenCaptureFromPath("../.Snaps/test.png").build());
		testCase1.pass("Enter the pwd as crmsfa is success");
		testCase1.pass("Login Button is clicked successfully");
		
		//To generate all the data to report
		extent.flush();
	}

}
