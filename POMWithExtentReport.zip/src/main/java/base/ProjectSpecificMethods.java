package base;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import utils.ReadExcel;

public class ProjectSpecificMethods {
	
	
	public  ChromeDriver driver;
	public String excelFileName;
	public static ExtentHtmlReporter reporter;
	public static ExtentReports extent;
	
	public ExtentTest test;
	public ExtentTest node;
	public String testName, testDescription, testAuthor, testCategory;
	
	@BeforeSuite
	public void startReport() {
				reporter = new ExtentHtmlReporter("./ExtentReports/result.html");
				reporter.setAppendExisting(true);
				extent = new ExtentReports();
				extent.attachReporter(reporter);
	}
	
	public long takeSnap() throws IOException {
		
		long ranNum = (long) (Math.random() * 9999999999L);
		
		File source = driver.getScreenshotAs(OutputType.FILE);
		File target = new File("./snaps/img"+ranNum+".png");
		FileUtils.copyFile(source, target);
		
		return ranNum;

	}
	
	@BeforeClass
	public void testDetails() {
		test = extent.createTest(testName, testDescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);
	}
	
	public void reportStep(String msg, String status) throws IOException {
		if(status.equalsIgnoreCase("pass")) {
			node.pass(msg, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}
		else {
			node.fail(msg, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
			throw new RuntimeException();
		}
	
	}
	
			
	@BeforeMethod
	public void startApp() throws InterruptedException {
		
		node = test.createNode(testName);	
				
		//WebDriverManager.chromedriver().setup();
		System.setProperty("webdriver.chrome.driver","./Driver/chromedriver.exe");
		Thread.sleep(3000);
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	}
	
	@AfterMethod
	public void closeBrowser() {
		driver.close();

	}
	
	@DataProvider(name="Data")
	public String[][] sendData() throws IOException {
		
		return ReadExcel.ReadData(excelFileName);

	}
	
	@AfterSuite
	public void endReport() {
		extent.flush();

	}
	
	
	/*
	 * public static ChromeDriver driver; public static ExtentHtmlReporter reporter;
	 * public static ExtentReports extent; public String excelFilename; public
	 * String testname,testDescription,testAuthor,testCategory;
	 * 
	 * public ExtentTest test,node;
	 */
	
	
	
	/*
	 * @BeforeSuite public void startReport() { reporter = new
	 * ExtentHtmlReporter("./ExtentReports/result.html");
	 * reporter.setAppendExisting(true);//To keep history extent = new
	 * ExtentReports(); extent.attachReporter(reporter); }
	 * 
	 * 
	 * @BeforeClass public void testDetails() { test = extent.createTest(testname,
	 * testDescription); test.assignAuthor(testAuthor);
	 * test.assignCategory(testCategory); }
	 * 
	 * public void reportStep(String msg, String status ) {
	 * if(status.equalsIgnoreCase("Pass")) { test.pass(msg); } else {
	 * test.fail(msg); }
	 * 
	 * }
	 * 
	 * @BeforeMethod public void precondition() throws InterruptedException{ node =
	 * test.createNode(testname); System.setProperty("webdriver.chrome.driver",
	 * "./Driver/chromedriver.exe"); Thread.sleep(3000); driver = new
	 * ChromeDriver(); driver.manage().window().maximize();
	 * driver.get("http://leaftaps.com/opentaps/");
	 * driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); }
	 * 
	 * @DataProvider(name = "Data") public String[][] sendData() throws IOException
	 * { return ReadExcel.ReadData(excelFilename); }
	 * 
	 * 
	 * @AfterMethod public void postcondition(){ driver.close();
	 * 
	 * }
	 * 
	 * @AfterSuite public void endReport() { extent.flush();
	 * 
	 * }
	 */
	  
	 

}
