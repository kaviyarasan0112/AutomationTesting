package pages;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import steps.BaseClass;


public class LoginPage_C extends BaseClass{

	 
	/*
	 * @FindBy(how=How.ID,using="username") private WebElement eleUserName;
	 * 
	 * @FindBy(how=How.ID,using="password") private WebElement elePassword;
	 * 
	 * @FindBy(how=How.CLASS_NAME,using="decorativeSubmit") private WebElement
	 * eleLogin;
	 * 
	 * @FindBy(how=How.ID, using = "errorDiv") private WebElement eleVerifyErrMsg;
	 */
	
	public LoginPage_C(RemoteWebDriver driver) {
		BaseClass.driver=driver;
	}
	
	
	public LoginPage_C enterTheUsernameAsDemosalesmanager(String username) {
		driver.findElementById("username").sendKeys(username);
	    return this;
	}


	public LoginPage_C enterThePasswordAsCrmsfa(String password) {
		driver.findElementById("password").sendKeys(password);
		return this;
	}

	
	public HomePage_C clickOnTheLoginButton() {
		driver.findElementByClassName("decorativeSubmit").click();
		System.out.println(driver.getSessionId());
		return new HomePage_C(driver);
	}

	
	public LoginPage_C homepageShouldBeDisplayed() {
		 String ActualTitle = driver.getTitle();
		 String ExpectedTitle="Leaftaps - TestLeaf Automation Platform";
		 Assert.assertEquals(ActualTitle, ExpectedTitle);
		 return this;
	}
	

	public LoginPage_C ErrorMessageShouldBeDisplayed() {
		String ActualTitle = driver.getTitle();
		String ExpectedTitle="Leaftaps - TestLeaf Automation Platform";
		Assert.assertEquals(ActualTitle, ExpectedTitle);
		return this;
	}
	
	
	
	
}
