package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import steps.BaseClass;



public class MyLeadsPage_C extends BaseClass {

	public MyLeadsPage_C(RemoteWebDriver driver){
		BaseClass.driver = driver;
		PageFactory.initElements(driver, this);		
	}
	
	@FindBy(how=How.LINK_TEXT,using="Create Lead")
	private WebElement elecreateLead;
	 
	public CreateLeadPage_C clickCreateLead(){
		elecreateLead.click();
		return new CreateLeadPage_C(driver);
	}

	@FindBy(how=How.LINK_TEXT,using="Find Leads")
	public WebElement elefindLead;
	
	public FindLeadPage_C clickFindLead(){
		elefindLead.click();
		return new FindLeadPage_C(driver);
	}
	
	@FindBy(how=How.LINK_TEXT,using="Merge Leads")
	public WebElement elemergeLead;
	
	public MergeLeadPage clickMergeLead(){
		click(elemergeLead);		
		return new MergeLeadPage(driver);
	}
	
	

}
