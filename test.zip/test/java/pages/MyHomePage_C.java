package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;



import steps.BaseClass;




public class MyHomePage_C extends BaseClass {

	public MyHomePage_C(RemoteWebDriver driver){
		BaseClass.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how=How.LINK_TEXT,using="Leads")
	public WebElement eleLeadLink;
	
	public MyLeadsPage_C clickLeadLink(){
		eleLeadLink.click();
		return new MyLeadsPage_C(driver);
	}


}
