package com.TestLeaf.Pages;

import com.TestLeaf.Base.BaseClass;

public class Loginpage extends BaseClass {
	
	public void LoginOrCreatebutton() {
		driver.findElementByCss
	}

}
