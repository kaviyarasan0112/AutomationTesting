package com.TestLeaf.StepDefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class Logintest   {
	
	@Given("click on the login or Create Account")
	public void click_on_the_login_or_Create_Account() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@And("Enter the mobile number <MobileNo>")
	public void enter_the_mobile_number_MobileNo() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@When("Click on the continue button")
	public void click_on_the_continue_button() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@And("Enter the OTP")
	public void enter_the_OTP() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@And("click on the Login button")
	public void click_on_the_Login_button() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}


}
