package collections.week3.Day2;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections4.map.HashedMap;

public class MapConcept {

	public static void main(String[] args) {
		
		Map<Integer, String> mp=new HashMap<Integer, String>();
		
		  mp.put(1, "Kavi"); 
		  mp.put(2, "Anand");
		  mp.put(3, "Baji");
		  System.out.println(mp.get(3));
		  boolean containsKey = mp.containsKey(3);
		  System.out.println(containsKey);
		  boolean containsValue = mp.containsValue("Anand");
		  System.out.println(containsValue);
		  //System.out.println(mp.get(1));//get(keyValue)
		 // mp.clear();
		  
		  
		
		  Map<Integer, String> mp1=new HashMap<Integer, String>(); 
		  mp1.putAll(mp);
		  
		  for (Entry<Integer, String> m : mp1.entrySet()) 
		  {
		  System.out.println(m.getKey()+" "+m.getValue()); 
		  }
		 
		  
		 
			 
	}
	
}
