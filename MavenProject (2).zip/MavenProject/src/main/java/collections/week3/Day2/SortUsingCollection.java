package collections.week3.Day2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class SortUsingCollection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] input= {"HCL","Wipro","Aspire Systems","CTS","InfoSYS"};
		
		
		//We use length property to find length of Array in Java and size() to find size of ArrayList.
		//Array
		int lengthOfCompany = input.length;
		System.out.println(lengthOfCompany);
		for (String comValues : input) {
			System.out.println(comValues);
		}
		
		
		List<String> values=new ArrayList<String>();
		//List<String> values=new LinkedList<String>();
		for (String eachInput : input) {
			values.add(eachInput);	
		}
		String stringFirstIndex = values.get(0);
		System.out.println("First Index "+stringFirstIndex);
		
		int lastIndexOf =values.lastIndexOf("CTS");
		System.out.println("Last Index "+ lastIndexOf);
		//System.out.println(values);
		
		Collections.sort(values);
		int companySize = values.size();
		System.out.println(companySize);
		
		
		//1. For loop
		
		/*
		 * for (int i = 0; i < companySize; i++) {
		 * 
		 * System.out.println(values.get(i));
		 * 
		 * }
		 */
		
		//2. foreach
		/*
		 * for (String string : values) {
		 * 
		 * }
		 */
		//3. Iterator
		
		
		System.out.println("---Iterator");
		
		Iterator<String> com = values.iterator();
		while(com.hasNext()) {
			System.out.println(com.next());
		}
		
		
		
		
	}

}
