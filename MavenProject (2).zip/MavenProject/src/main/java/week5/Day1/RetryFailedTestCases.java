package week5.Day1;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryFailedTestCases implements IRetryAnalyzer {
	
	int maxRetry = 3;
	int retryCount = 0;
	
	//boolean retry present in the IRetryAnalyzer interface

	public boolean retry(ITestResult result) {

		if(!result.isSuccess() && retryCount < maxRetry) {
			retryCount++;
			return true;
		}
		
		return false;
	}

}
