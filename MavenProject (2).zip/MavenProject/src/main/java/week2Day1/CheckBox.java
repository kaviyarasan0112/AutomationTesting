package week2Day1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class CheckBox {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		
		String property = System.getProperty("webdriver.chrome.driver");
		
		System.out.println(property);
					
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver();
						

		//to maximize the browser 
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  
		//to load application url
		driver.get("https://www.sc.com/in/help/online-banking/");
		WebElement Login = driver.findElementByCssSelector(".sc-hdr__login-btn");
		Actions builder=new Actions(driver);
		builder.moveToElement(Login).perform();
		Thread.sleep(3000);
		List<WebElement> list = driver.findElementsByXPath("//div[@class='sc-minimgnv']/ul/li");
		
		
		System.out.println(list);
		//driver.get("http://leafground.com/");
		
		
		/*
		 * driver.findElementByXPath("//h5[contains(text(),'Checkbox')]").click();
		 * 
		 * driver.findElementByXPath("(//input[contains(@type,'checkbox')])[1]").click()
		 * ;
		 * 
		 * driver.findElementByXPath("(//input[contains(@type,'checkbox')])[2]").click()
		 * ;
		 * 
		 * WebElement SelChecked = driver.
		 * findElementByXPath("//label[text()='Confirm Selenium is checked']/following::input"
		 * );
		 * System.out.println("TO confirm selenium is checked "+SelChecked.isSelected())
		 * ;
		 * 
		 * WebElement deselectCheckbox = driver.
		 * findElementByXPath("(//label[text()='DeSelect only checked']/following::input)[2]"
		 * ); deselectCheckbox.click();
		 * 
		 * Thread.sleep(3000);
		 * 
		 * driver.
		 * findElementByXPath("(//label[text()='Select all below checkboxes ']/following::input)[1]"
		 * ).click(); driver.
		 * findElementByXPath("(//label[text()='Select all below checkboxes ']/following::input)[2]"
		 * ).click(); driver.
		 * findElementByXPath("(//label[text()='Select all below checkboxes ']/following::input)[3]"
		 * ).click(); driver.
		 * findElementByXPath("(//label[text()='Select all below checkboxes ']/following::input)[4]"
		 * ).click();
		 * 
		 * WebElement checkbox5 = driver.
		 * findElementByXPath("(//label[text()='Select all below checkboxes ']/following::input)[5]"
		 * ); checkbox5.click();
		 * System.out.println("CheckBox5 is currently selected "+checkbox5.isSelected())
		 * ;
		 * 
		 * Thread.sleep(3000);
		 * 
		 * driver.quit();
		 */
		
	}

}
