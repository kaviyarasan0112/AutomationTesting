package week2Day1;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LeafGround {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./ChromeDriver/chromedriver.exe");
		
		String property = System.getProperty("webdriver.chrome.driver");
		
		System.out.println(property);
					
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver();
						

		//to maximize the browser 
		driver.manage().window().maximize();
  
		//to load application url
		driver.get("http://leafground.com/");
		driver.findElementByLinkText("Edit").click();
		driver.findElementById("email").sendKeys("Test@abc.com");
		WebElement secField = driver.findElementByXPath("//input[@type='text' and @value='Append ']");
		Thread.sleep(3000);
		secField.sendKeys("Test");
		Thread.sleep(3000);
		secField.sendKeys(Keys.TAB);
		
		String attributeOfThird = driver.findElementByName("username").getAttribute("value");
		System.out.println(attributeOfThird);
		
		driver.findElementByXPath("//input[@value='Clear me!!']").clear();
		boolean enabled = driver.findElementByXPath("//input[@disabled='true']").isEnabled();
		System.out.println(enabled);
		
		
		
	}

}
