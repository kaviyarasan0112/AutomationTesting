package week2Day1;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ChromeSetup {
	
	public void Setup() {
		//to setup chrome driver
		
		WebDriverManager.chromedriver().setup();
		//System.setProperty("webdriver.chrome.driver", "./ChromeDriver/chromedriver.exe");
			
		String property = System.getProperty("webdriver.chrome.driver");
		
		System.out.println(property);
					
		

}
}
