package week3.Day1;

public class Mobile {

	public void sendMsg() {
		System.out.println("Sending Msg...");
	}
	
	public void makeCall() {
		System.out.println("Making Call...");
	}
	
	public void saveContact() {
		System.out.println("Saving contact...");
	}
	
	
	
	
	

	}

