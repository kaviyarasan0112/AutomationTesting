package week3.Day1;

public class Vehicle {
	

	String brand = "Hyundai";
	
	public void applyBrake() {
		System.out.println("applied brake - from vehicle");

	}
	
	public void soundHorn() {
		System.out.println("sound horn");

	}


}
