package week3.Day1;

public class AndroidPhone extends Mobile {
	
	protected void takeVideo() {
		System.out.println("Taking video...");
	}
	
	

}
