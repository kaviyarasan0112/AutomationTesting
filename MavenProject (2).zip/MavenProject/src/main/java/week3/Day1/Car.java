package week3.Day1;

public class Car extends Vehicle{
		
	 public void switchOnAC() {
			System.out.println("switched on AC");

		}

	}

