package week4.day1;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class FrameLeafGround {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		String property = System.getProperty("webdriver.chrome.driver");
		System.out.println(property);
		//To disable notifications of the browser
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notofications");			
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver(options);
		//to maximize the browser 
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//driver.get("http://leafground.com/pages/frame.html");
		driver.get("https://www.irctc.co.in/");
		driver.findElementByXPath("//button[@class='btn btn-primary']").click();
		WebElement fromele = driver.findElementByXPath("//input[@placeholder='From*']");
		fromele.sendKeys("Chennai");
		fromele.sendKeys(Keys.ENTER);
		driver.findElementByXPath("//input[@placeholder='To*']").sendKeys("MS");
		Thread.sleep(3000);
		driver.findElementByXPath("//button[@class='search_btn' and @label='Find Trains']").click();
		//frame
		
//		driver.switchTo().frame(0); //
//		  driver.findElementByXPath("//button[contains(text(),'Click Me')]").click();
//		  Thread.sleep(3000);
//		  driver.switchTo().parentFrame();
//		 		 
//		//Nested Frame
//		
//		  driver.switchTo().frame(1); 
//		  driver.switchTo().frame(0); 
//		  Thread.sleep(3000);
//		  driver.findElementByXPath("//button[@id='Click1']").click();
//		  Thread.sleep(3000); 
		 
		//to get total number of frames
		
		/*
		 * List<WebElement> totalNumberOfTagName
		 * =driver.findElementsByTagName("iframe"); int size =
		 * totalNumberOfTagName.size(); System.out.println(size); //driver.close();
		 */
		
		
		

	}

}
