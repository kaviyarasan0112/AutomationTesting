package week4.day1;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class RobotClassSirius {

	public static void main(String[] args) throws InterruptedException, AWTException {
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");	
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://grclopsnlbm910/OPSPortal/EnvironmentPage.aspx?EnvironmentID=213");	
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);		

		WebElement signIn = driver.findElement(By.xpath("//a[contains(text(),'Sign in as a different user')]"));
		signIn.click();
		
		Thread.sleep(2000);
		
		// Store the copied text in the clipboard
		StringSelection stringSelection = new StringSelection("uk1test\thiyagk");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
			
		// Paste it using Robot class
		Robot robotUn = new Robot();

		// Enter to confirm it is uploaded
		robotUn.keyPress(KeyEvent.VK_CONTROL);			
		robotUn.keyPress(KeyEvent.VK_V);

		robotUn.keyRelease(KeyEvent.VK_V);
		robotUn.keyRelease(KeyEvent.VK_CONTROL);	

		Thread.sleep(5000);

		robotUn.keyPress(KeyEvent.VK_TAB);
		robotUn.keyRelease(KeyEvent.VK_TAB);
		
		StringSelection stringSelection1 = new StringSelection("Jan@2021");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection1, null);
		
		Robot robotPwd = new Robot();

		// Enter to confirm it is uploaded
		robotPwd.keyPress(KeyEvent.VK_CONTROL);			
		robotPwd.keyPress(KeyEvent.VK_V);

		robotPwd.keyRelease(KeyEvent.VK_V);
		robotPwd.keyRelease(KeyEvent.VK_CONTROL);	

		Thread.sleep(3000);

		robotPwd.keyPress(KeyEvent.VK_TAB);
		robotPwd.keyRelease(KeyEvent.VK_TAB);
		
		Thread.sleep(3000);
		
		robotPwd.keyPress(KeyEvent.VK_ENTER);
		robotPwd.keyRelease(KeyEvent.VK_ENTER);
		
		

	}

}
