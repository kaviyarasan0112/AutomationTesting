package week4.day1;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChromeDownloads {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		String property = System.getProperty("webdriver.chrome.driver");
		System.out.println(property);
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver();
		driver.get("chrome://downloads/");
		
		//Convert the driver to javaScriptExecutor
		JavascriptExecutor jse=(JavascriptExecutor) driver;
		//Use the method Execute to locate the element and Convert the javascript element to webelement
		WebElement chromeDownloads=(WebElement) jse.executeScript("return document.querySelector('downloads-manager').shadowRoot.querySelector('downloads-toolbar#toolbar').shadowRoot.querySelector('cr-toolbar#toolbar').shadowRoot.querySelector('cr-toolbar-search-field#search').shadowRoot.querySelector('div#searchTerm>input#searchInput')");
		//Store the value to pass using setAttribute Method
		String js="arguments[0].setAttribute('value','ToolsQA')";
	
		((JavascriptExecutor)driver).executeScript(js, chromeDownloads);

	}

}
