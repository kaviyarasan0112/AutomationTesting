package week4.day1;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ShadowDOM {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		String property = System.getProperty("webdriver.chrome.driver");
		System.out.println(property);
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("https://www.google.com");
		driver.manage().window().maximize();
		driver.switchTo().frame(0);
		driver.findElementByXPath("(//span[@class='RveJvd snByac'])[3]").click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(0);
		
		JavascriptExecutor jse=(JavascriptExecutor) driver;
		
		WebElement googleSearchBar=(WebElement) jse.executeScript("return document.querySelector('ntp-app').shadowRoot.querySelector('ntp-realbox').shadowRoot.querySelector('div#inputWrapper>input')");
		
		String js="arguments[0].setAttribute('value', 'ToolsQA')";
		
		((JavascriptExecutor)driver).executeScript(js, googleSearchBar);
		
		
		
	}

}
