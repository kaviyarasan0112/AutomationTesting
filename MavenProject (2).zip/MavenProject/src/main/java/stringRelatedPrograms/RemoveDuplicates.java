package stringRelatedPrograms;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class RemoveDuplicates {
	
	public static void main(String[] args) {
		
		String[] input= {"HCL","Wipro","Aspire Systems","CTS","InfoSYS","CTS","HCL"};
		
		//set Will not allow duplicates where list allows duplicates
		
		Set<String> dup=new LinkedHashSet<String>();
		//List<String> duplicateValue=new ArrayList<String>();
		
		
		for (String eachValue : input) {
			dup.add(eachValue);
		}
		
		System.out.println(dup);
		
		
		
	}
	
	

}
