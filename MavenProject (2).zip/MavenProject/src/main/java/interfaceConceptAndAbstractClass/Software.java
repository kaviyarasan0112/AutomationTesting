package interfaceConceptAndAbstractClass;

public interface Software {
	
	public abstract void softwareResources();
	int softwareApps=100;
	
}
