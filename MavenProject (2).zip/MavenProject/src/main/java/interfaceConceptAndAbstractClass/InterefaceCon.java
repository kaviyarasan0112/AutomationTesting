package interfaceConceptAndAbstractClass;

public class InterefaceCon {

}
