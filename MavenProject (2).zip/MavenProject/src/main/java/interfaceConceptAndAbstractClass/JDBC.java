package interfaceConceptAndAbstractClass;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBC {

	public static void main(String[] args) throws SQLException {
		Connection con=DriverManager.getConnection("SiriusUKFTA2SQL\\SIRIUS (UK1TEST\\thiyagk)");
		Statement stmt = con.createStatement();
		stmt.execute("select * from client");
		con.close();
		

	}

}
