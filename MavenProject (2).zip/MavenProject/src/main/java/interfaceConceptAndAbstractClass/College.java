package interfaceConceptAndAbstractClass;

public  class College extends University{

	void ug(int a, int b) {
		System.out.println(a+b);
		
	}
	
	public static void main(String[] args) {
		
		College obj1=new College();
		obj1.pg();
		obj1.ug(10, 5);
		System.out.println(obj1.dept);
		
	}

	

}
