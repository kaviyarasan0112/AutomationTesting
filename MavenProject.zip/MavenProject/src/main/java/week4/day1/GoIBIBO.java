package week4.day1;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.target.model.SessionID;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.grpc.Context.Key;

public class GoIBIBO {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		RemoteWebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.goibibo.com/");
		
		/*
		 * WebElement more =
		 * driver.findElementByCssSelector(".tip.tip_top.white.moreSubLinks");
		 * 
		 * WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(10));
		 * wait.until(ExpectedConditions.visibilityOf(more));
		 * 
		 * Actions builder=new Actions(driver); builder.moveToElement(more).perform();
		 * 
		 */
		
		WebElement hotels = driver.findElementByXPath("//ul[@class='mainLinks']/li[2]");
		String text = hotels.getText();
		System.out.println(text);
		hotels.click();
		
		List<WebElement> country = driver.findElementsByName("CountryType");
		WebElement Internatoinal = country.get(1);
		Internatoinal.click();
		
		System.out.println(Internatoinal.isSelected());
		
		String windowSessionID = driver.getWindowHandle();
		System.out.println(windowSessionID);
		SessionId sessionId = driver.getSessionId();
		System.out.println(sessionId);
		
		WebElement where = driver.findElementByCssSelector("input.HomePageAutosuggeststyles__SearchInputStyles-sc-1v6s32j-1.cYUrYT");
	    //where.sendKeys("Maldives");
			
		where.sendKeys("Maldives",Keys.DOWN,Keys.ENTER);
		
		String expectedTitle="Oops! Something went wrong";
		String actualTitle = driver.findElementByCssSelector(".SomethingWentWrongstyles__TextContainer-b7ont0-1.iYbczB>h1").getText();
		Assert.assertEquals(actualTitle, expectedTitle);
		/*
		 * where.click(); WebElement maldives = driver.
		 * findElementByXPath("//ul[@id='downshift-1-menu' and @role='listbox']//ul/li[1]"
		 * ); WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(10));
		 * wait.until(ExpectedConditions.elementToBeClickable(maldives));
		 * maldives.click();
		 */
		
		
		
		
		/*
		 * WebElement maldives = driver.
		 * findElementByXPath("//ul[@class='TrendingDestinationsUI__ListTrendInnerWrap-qz22gb-2 cgqysM']/li[1]"
		 * );
		 * 
		 * maldives.click();
		 */
		
		/*
		 * WebElement searchHotels = driver.findElementByLinkText("Search Hotels");
		 * searchHotels.click();
		 */
		
		
		
		
       
		

	}

}
