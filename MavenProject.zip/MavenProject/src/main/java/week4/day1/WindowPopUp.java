package week4.day1;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

public class WindowPopUp {

	public static void main(String[] args) throws InterruptedException, IOException, AWTException {
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		//String property = System.getProperty("webdriver.chrome.driver");
		//System.out.println(property);			
		//To open Chrome Browser
		RemoteWebDriver driver = new ChromeDriver();
		//to maximize the browser 
		driver.manage().window().maximize();
		/*
		 * driver.get("http://leafground.com/"); Thread.sleep(3000); driver.
		 * findElementByCssSelector("a[class='wp-categories-link maxheight'][href='pages/upload.html']"
		 * ).click();
		 * //driver.findElementByCssSelector("input[name='filename'][type='file']").
		 * sendKeys("D:\\Selenium Docs\\LoginData.xlsx");
		 * Runtime.getRuntime().exec("C://Users//thiyagk//Desktop//FileUpload.exe");
		 */
		
		driver.get("http://leafground.com/");
		  Thread.sleep(3000);
		  driver.findElementByCssSelector("a[class='wp-categories-link maxheight'][href='pages/upload.html']").click(); 
		  Thread.sleep(3000);
		  
		/*
		 * driver.findElementByXPath("//input[@name='filename'][@type='file']").
		 * sendKeys("D:\\Selenium Docs\\CreateLeadTD.xlsx");
		 */
		  
		  
		 
		  WebElement chooseFile = driver.findElementByXPath("//input[@name='filename'][@type='file']");
		  chooseFile.click();
		  Robot robot=new Robot();
		  robot.keyPress(KeyEvent.VK_ENTER);
		 
	}

}
