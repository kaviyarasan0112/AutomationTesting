package week4.day1;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragDropLeafGroundApp {

	public static void main(String[] args) throws InterruptedException {
		

		System.setProperty("webdriver.chrome.driver", "./ChromeDriver/chromedriver.exe");
		String property = System.getProperty("webdriver.chrome.driver");
		System.out.println(property);
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver();
		//to maximize the browser 
		driver.manage().window().maximize();
		
		//to load application url
		driver.get("http://leafground.com/");
		
		//Sortable
		/*
		 * driver.findElementByXPath("//h5[text()='Sortable']").click(); Actions
		 * builder=new Actions(driver); WebElement source =
		 * driver.findElementByXPath("//ul[@id='sortable']/li[1]"); WebElement target =
		 * driver.findElementByXPath("//ul[@id='sortable']/li[4]"); Thread.sleep(3000);
		 * builder.dragAndDrop(source, target).perform();
		 */
		
		
		//Droppable
		driver.findElementByXPath("//h5[text()='Droppable']").click();
		Actions builder=new Actions(driver);
		WebElement draggable = driver.findElementByXPath("//div[@id='draggable']");
		WebElement droppable = driver.findElementByXPath("//div[@id='droppable']");
		Thread.sleep(3000);
		builder.dragAndDrop(draggable, droppable).perform();
			
	}
}
