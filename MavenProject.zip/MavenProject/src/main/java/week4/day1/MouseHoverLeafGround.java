package week4.day1;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseHoverLeafGround {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "./ChromeDriver/chromedriver.exe");
		String property = System.getProperty("webdriver.chrome.driver");
		System.out.println(property);
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver();
		//to maximize the browser 
		driver.manage().window().maximize();
		
		//to load application url
		driver.get("http://leafground.com/");
		driver.findElementByXPath("//h5[text()='Mouse Hover']").click();
		Actions builder=new Actions(driver);
		WebElement testLeafCourses = driver.findElementByLinkText("TestLeaf Courses");
		builder.moveToElement(testLeafCourses).perform();
		

	}

}
