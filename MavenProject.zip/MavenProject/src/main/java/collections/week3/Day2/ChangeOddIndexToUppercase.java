package collections.week3.Day2;

public class ChangeOddIndexToUppercase {
	
	public static void main(String[] args) {
		
		String test="changeme";
		
		char[] charArray = test.toCharArray();
		
		for (int i = 0; i < charArray.length; i++) {
			
		if(i%2!=0) {

			char c = charArray[i];
			
			System.out.println(c);	
			
		}
		
			
		}
		
	}

}
