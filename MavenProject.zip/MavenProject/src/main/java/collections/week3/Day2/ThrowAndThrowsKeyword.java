package collections.week3.Day2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ThrowAndThrowsKeyword {
	
	public int divide(int num1,int num2) {
		
		//By using throw we can explicitly throw the exception
		//To handle this expection, we need to enlcose with try catch block
		
		int result;
		if(num2>num1) {
			throw new ArithmeticException("Second Number is greater than first number");
		}
		else {
			result=num1/num2;
		}
		System.out.println(result);
		return result;
		
	}
	
	public void accessFile() throws FileNotFoundException {
		FileInputStream fis=new FileInputStream("./src/TestData/CreateLeadTD.xlsx");
	}

	public static void main(String[] args) throws FileNotFoundException {
		
		ThrowAndThrowsKeyword obj=new ThrowAndThrowsKeyword();
		obj.divide(10, 5);
	
		
		try{
			obj.accessFile();
		}
		catch(FileNotFoundException e) {
			System.out.println(e);
		}
		
		System.out.println("This is the last line of the code");

	}

}
