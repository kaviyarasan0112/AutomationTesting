package collections.week3.Day2;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class FindDuplicatesinStringUsingHashMap {
	
	public static void main(String[] args) {
		
		String s="I am Kaviyarasan";
		
		Map<Character,Integer> map = new HashMap<Character,Integer>();
		for (int i = 0; i < s.length(); i++) {
			
		 char c = s.charAt(i);
		
		  if (map.containsKey(c)) {
		   int cnt = map.get(c);
		    map.put(c, ++cnt);
		  } 
		  else {
			  map.put(c, 1);
		  }		  
		 
		}
		 for (Entry<Character, Integer> m : map.entrySet()) {
			  	System.out.print("["+m.getKey()+" "+m.getValue()+"]"+" ");
		}
		
	}

}
