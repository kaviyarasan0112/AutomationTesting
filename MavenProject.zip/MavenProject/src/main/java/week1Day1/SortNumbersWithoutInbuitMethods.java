package week1Day1;

public class SortNumbersWithoutInbuitMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]={2,4,3,5};
		int temp=0;
		int n=4;
		
		for(int i=0;i<n;i++) {
			  for(int j=i+1;j<n;j++) { 
				  if(a[i]>a[j]) { 
					  temp=a[i]; 
					  a[i]=a[j]; 
					  a[j]=temp; }
			  
			  }
			 
			System.out.print(a[i]);
			
		}
		

	}

}
