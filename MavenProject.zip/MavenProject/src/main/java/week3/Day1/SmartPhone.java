package week3.Day1;

public class SmartPhone extends AndroidPhone{

	public void connectWhatsApp(){
		System.out.println("Connecting WhatsApp...");
	}
	
	protected void takeVideo() {
		System.out.println("Taking video from smartphone...");
	}
	
	public static void main(String[] args) {
		
		SmartPhone mob=new  SmartPhone();
		mob.sendMsg();
		mob.saveContact();
		mob.makeCall();
		mob.takeVideo();
		mob.connectWhatsApp();
	}
	
}
