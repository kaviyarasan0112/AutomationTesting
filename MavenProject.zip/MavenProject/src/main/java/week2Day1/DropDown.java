package week2Day1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDown {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		
		String property = System.getProperty("webdriver.chrome.driver");
		
		System.out.println(property);
					
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver();
						

		//to maximize the browser 
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  
		//to load application url
		driver.get("http://leafground.com/");
		driver.findElementByXPath("//h5[text()='Drop down']").click();;
		List<WebElement> ddlist = driver.findElementsByCssSelector("#dropdown1>option");
		System.out.println(ddlist.size());
		
		
		for (WebElement eachDD : ddlist) {
				System.out.println(eachDD.getText());
			}
		
		
		/*
		 * WebElement fourthElement = ddlist.get(3); fourthElement.click();
		 */

		
		/*
		 * Thread.sleep(3000);
		 * 
		 * WebElement dd4 =
		 * driver.findElementByXPath("(//div[@class='example']/select)[5]");
		 * dd4.sendKeys(Keys.ENTER); dd4.sendKeys(Keys.ARROW_DOWN);
		 * dd4.sendKeys(Keys.ENTER);
		 */
		
		/*
		 * WebElement dd5 =
		 * driver.findElementByXPath("(//div[@class='example']/select)[6]");
		 * 
		 * Select combo=new Select(dd5); List<WebElement> options = combo.getOptions();
		 * int size = options.size();
		 * 
		 * 
		 * 
		 * dd5.sendKeys(Keys.ENTER); dd5.sendKeys(Keys.ARROW_DOWN);
		 * dd5.sendKeys(Keys.ENTER); combo.selectByValue("2"); combo.selectByValue("3");
		 * combo.selectByValue("4");
		 * 
		 * Thread.sleep(3000);
		 * 
		 */		
		 
		
	}

}
