package week5.Day1;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.google.common.base.Function;

public class Wait {
	public  WebDriver driver;
	public WebDriverWait wait;

	@Test
	public void testWait() {
		
System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		
		String property = System.getProperty("webdriver.chrome.driver");
		
		System.out.println(property);
					
		//To open Chrome Browser
		 driver = new ChromeDriver();
		//to maximize the browser 
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://leafground.com/");
		/*
		 * WebElement ele =
		 * driver.findElement(By.xpath("//h5[text()='Wait to Disappear']/parent::a"));
		 * ele.click();
		 */
		//WebElement elementToBeDisappeared = driver.findElement(By.xpath("//button[@id='btn']/b"));
	
		/*
		 * wait=new WebDriverWait(driver, 1);
		 * wait.until(ExpectedConditions.invisibilityOf(elementToBeDisappeared)); String
		 * actualResult = driver.findElement(By.
		 * xpath("//div[@class='disappear' and @id='show']//strong")).getText(); String
		 * expectedResult="I know you can do it! Button is disappeared!";
		 * 
		 * String ActualheaderText =
		 * driver.findElement(By.xpath("//h1[@itemprop='name']")).getText(); String
		 * expectedheaderText ="Explicit Wait for Element Disappearanc";
		 * 
		 * SoftAssert sa=new SoftAssert(); sa.assertEquals(ActualheaderText,
		 * expectedheaderText); sa.assertEquals(actualResult, expectedResult);
		 * 
		 * sa.assertAll();
		 */
		
	
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver);
			     wait  .withTimeout(Duration.ofSeconds(30));
			      wait .pollingEvery(Duration.ofSeconds(5))
			       .ignoring(NoSuchElementException.class);

			   WebElement foo = wait.until(new Function<WebDriver, WebElement>() {
			     public WebElement apply(WebDriver driver) {
			       return driver.findElement(By.xpath("//h5[text()='Wait to Disappear']/parent::a"));
			     }
			   });
			   foo.click();
			   
			   String actualtitle = driver.getTitle();
			   String expectedTitle ="TestLeaf - Wait for Disappearance of Element";
			  Assert.assertEquals(actualtitle, expectedTitle);

		
	}
	
	

}
