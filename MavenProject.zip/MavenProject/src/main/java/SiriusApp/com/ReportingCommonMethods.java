package SiriusApp.com;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import week5.Day1.ReadExcel;

public class ReportingCommonMethods {
		public ChromeDriver driver;
		public String fileNameOfExcel;
		
		@BeforeMethod
		public void HomePage() throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		//String property = System.getProperty("webdriver.chrome.driver");
		//System.out.println(property);
		//To disable notifications of the browser
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notofications");			
		//To open Chrome Browser
		driver = new ChromeDriver(options);
		//to maximize the browser 
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://siriusukfta2.uk1test.group.internal/FTA2/Rrp.UI.Web/Default.aspx?_height=680&_width=1280");
		Thread.sleep(2000);
		driver.findElementByXPath("//img[@alt='Reporting']").click();
		Thread.sleep(2000);
		}
		
		@DataProvider(name = "TestData")
		public String[][] sendTestData() throws IOException {
			return ReadExcel.ReadData(fileNameOfExcel);
		}
	/*
	 * @AfterMethod public void close() { driver.close(); }
	 */

}
