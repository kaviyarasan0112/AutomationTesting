package hooks;

import org.openqa.selenium.remote.RemoteWebDriver;


public class BaseClass {
	
	public static RemoteWebDriver driver;

}
